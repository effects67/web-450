import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quiz-tech',
  templateUrl: './quiz-tech.component.html',
  styleUrls: ['./quiz-tech.component.css']
})
export class QuizTechComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
