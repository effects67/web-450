import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quiz-micro',
  templateUrl: './quiz-micro.component.html',
  styleUrls: ['./quiz-micro.component.css']
})
export class QuizMicroComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
