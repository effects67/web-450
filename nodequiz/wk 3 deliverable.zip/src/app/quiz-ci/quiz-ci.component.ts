import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quiz-ci',
  templateUrl: './quiz-ci.component.html',
  styleUrls: ['./quiz-ci.component.css']
})
export class QuizCiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
